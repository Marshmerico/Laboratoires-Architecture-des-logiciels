import java.util.*;

public class Admin {
    private int adminID;
    private String name;
    private String email;
    
    public Admin(int adminID, String name, String email) {
        this.adminID = adminID;
        this.name = name;
        this.email = email;
    }

    // Getters
    public int getAdminID() { return adminID; }
    public String getName() { return name; }
    public String getEmail() { return email; }

    // Méthodes simplifiées pour l'interface
    public void assignTicket(Ticket ticket, Admin admin) {
        // Cette logique est maintenant dans TicketController
    }

    public void closeTicket(Ticket ticket) {
        // Cette logique est maintenant dans TicketController
    }

    public void viewAllTickets() {
        // Cette logique est maintenant dans TicketInterface
    }
}