import java.util.*;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static TicketController ticketController;

    public static void main(String[] args) {
        // Création du contrôleur API (plus besoin d'initialiser les données localement)
        ticketController = new TicketController();

        System.out.println("===== Système de Gestion de Tickets =====");

        while (true) {
            System.out.println("\nConnexion :");
            System.out.println("1. Utilisateur");
            System.out.println("2. Administrateur");
            System.out.println("3. Quitter");
            int choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> {
                    User user = loginUser();
                    if (user != null) {
                        userMenu(user);
                    }
                }
                case 2 -> {
                    Admin admin = loginAdmin();
                    if (admin != null) {
                        adminMenu(admin);
                    }
                }
                case 3 -> {
                    System.out.println("Fin du programme.");
                    return;
                }
                default -> System.out.println("Choix invalide.");
            }
        }
    }

    // ================= CONNEXION UTILISATEUR =================
    private static User loginUser() {
        System.out.print("Entrez votre email utilisateur : ");
        String email = scanner.nextLine();

        User user = ticketController.loginUser(email);
        if (user != null) {
            System.out.println("Bienvenue " + user.getName() + " !");
        } else {
            System.out.println("Utilisateur introuvable.");
        }
        return user;
    }

    // ================= CONNEXION ADMIN =================
    private static Admin loginAdmin() {
        System.out.print("Entrez votre email administrateur : ");
        String email = scanner.nextLine();

        Admin admin = ticketController.loginAdmin(email);
        if (admin != null) {
            System.out.println("Bienvenue " + admin.getName() + " !");
        } else {
            System.out.println("Administrateur introuvable.");
        }
        return admin;
    }

    // ================= MENU UTILISATEUR =================
    private static void userMenu(User user) {
        while (true) {
            System.out.println("\n--- Menu Utilisateur (" + user.getName() + ") ---");
            System.out.println("1. Créer un ticket");
            System.out.println("2. Voir mes tickets");
            System.out.println("3. Ajouter un commentaire");
            System.out.println("4. Déconnexion");
            int choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> {
                    System.out.print("Titre : ");
                    String titre = scanner.nextLine();
                    System.out.print("Description : ");
                    String desc = scanner.nextLine();
                    System.out.print("Priorité (Haute/Moyenne/Basse) : ");
                    String priorite = scanner.nextLine();

                    boolean success = ticketController.createTicket(titre, desc, priorite, user.getUserID());
                    if (success) {
                        System.out.println("Ticket créé avec succès !");
                    } else {
                        System.out.println("Erreur lors de la création du ticket.");
                    }
                }
                case 2 -> {
                    List<Ticket> tickets = ticketController.getUserTickets(user.getUserID());
                    System.out.println("\nVos tickets :");
                    for (Ticket t : tickets) {
                        System.out.println("ID " + t.getTicketID() + " - " + t.getTitle() + " [" + t.getStatus() + "]");
                    }
                }
                case 3 -> {
                    System.out.print("ID du ticket : ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Commentaire : ");
                    String commentaire = scanner.nextLine();

                    boolean success = ticketController.addCommentToTicket(id, commentaire, user.getUserID());
                    if (success) {
                        System.out.println("Commentaire ajouté avec succès.");
                    } else {
                        System.out.println("Échec : ticket introuvable ou non autorisé.");
                    }
                }
                case 4 -> { return; }
                default -> System.out.println("Choix invalide.");
            }
        }
    }

    // ================= MENU ADMIN =================
    private static void adminMenu(Admin admin) {
        while (true) {
            System.out.println("\n--- Menu Admin (" + admin.getName() + ") ---");
            System.out.println("1. Voir tous les tickets");
            System.out.println("2. Assigner un ticket");
            System.out.println("3. Mettre à jour le statut");
            System.out.println("4. Fermer un ticket");
            System.out.println("5. Voir mes tickets assignés");
            System.out.println("6. Déconnexion");
            int choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> {
                    List<Ticket> tickets = ticketController.getAllTickets();
                    System.out.println("\nTous les tickets :");
                    for (Ticket t : tickets) {
                        System.out.println("ID " + t.getTicketID() + " - " + t.getTitle() + " [" + t.getStatus() + "]");
                    }
                }
                case 2 -> {
                    System.out.print("ID du ticket à assigner : ");
                    int ticketID = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("ID de l'Admin assigné : ");
                    int adminID = scanner.nextInt();
                    scanner.nextLine();

                    boolean success = ticketController.assignTicket(ticketID, adminID);
                    if (success) {
                        System.out.println("Ticket " + ticketID + " assigné avec succès.");
                    } else {
                        System.out.println("Échec de l'assignation.");
                    }
                }
                case 3 -> {
                    System.out.print("ID du ticket à mettre à jour : ");
                    int ticketID = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Nouveau statut (OUVERT/ASSIGNE/VALIDATION/TERMINE) : ");
                    String nouveauStatut = scanner.nextLine();

                    boolean success = ticketController.updateTicketStatus(ticketID, nouveauStatut);
                    if (success) {
                        System.out.println("Statut mis à jour avec succès.");
                    } else {
                        System.out.println("Échec : ticket introuvable ou statut invalide.");
                    }
                }
                case 4 -> {
                    System.out.print("ID du ticket à fermer : ");
                    int ticketID = scanner.nextInt();
                    scanner.nextLine();

                    boolean success = ticketController.closeTicket(ticketID);
                    if (success) {
                        System.out.println("Ticket fermé avec succès.");
                    } else {
                        System.out.println("Échec : ticket introuvable.");
                    }
                }
                case 5 -> {
                    List<Ticket> tickets = ticketController.getAdminAssignedTickets(admin.getAdminID());
                    System.out.println("\nTickets assignés à " + admin.getName() + " :");
                    for (Ticket t : tickets) {
                        System.out.println("ID " + t.getTicketID() + " - " + t.getTitle() + " [" + t.getStatus() + "]");
                    }
                }
                case 6 -> { return; }
                default -> System.out.println("Choix invalide.");
            }
        }
    }
}