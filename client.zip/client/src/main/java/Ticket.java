import java.util.*;

public class Ticket {
    private int ticketID;
    private String title;
    private String description;
    private String status;
    private String priority;
    private int creatorID;
    private int assignedAdminID;

    // Constructeur simplifié pour l'interface
    public Ticket(int ticketID, String title, String description, String status, String priority, int creatorID) {
        this.ticketID = ticketID;
        this.title = title;
        this.description = description;
        this.status = status;
        this.priority = priority;
        this.creatorID = creatorID;
        this.assignedAdminID = -1; // Non assigné par défaut
    }

    // Getters
    public int getTicketID() { return ticketID; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getStatus() { return status; }
    public String getPriority() { return priority; }
    public int getCreatorID() { return creatorID; }
    public int getAssignedAdminID() { return assignedAdminID; }

    // Setters
    public void setAssignedAdminID(int adminID) { this.assignedAdminID = adminID; }
    
    public void updateStatus(String newStatus) { 
        this.status = newStatus; 
    }
    
    public void assignTo(int adminID) { 
        this.assignedAdminID = adminID; 
        this.status = "ASSIGNE";
    }
    
    public void addComment(String comment, int userID) {
        this.description = this.description + "\nCommentaire (User " + userID + "): " + comment;
    }

    @Override
    public String toString() {
        return "ID: " + ticketID + " - " + title + " [" + status + "]";
    }
}