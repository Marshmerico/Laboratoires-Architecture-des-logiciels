// CORRECTION DES IMPORTS - utilise des points au lieu de slashs
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.api.*;
import io.swagger.client.model.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TicketController {
    private ApiClient apiClient;
    private AuthenticationApi authApi;
    private TicketsApi ticketsApi;
    private UsersApi usersApi;
    private AdminsApi adminsApi;

    public TicketController() {
        this.apiClient = new ApiClient();
        this.apiClient.setBasePath("http://localhost:8080/api");
        this.apiClient.addDefaultHeader("Content-Type", "application/json");
        this.apiClient.addDefaultHeader("Accept", "application/json");

        this.authApi = new AuthenticationApi(apiClient);
        this.ticketsApi = new TicketsApi(apiClient);
        this.usersApi = new UsersApi(apiClient);
        this.adminsApi = new AdminsApi(apiClient);
    }
    
    // ================= MÉTHODES DE CONNEXION =================
    
    public User loginUser(String email) {
        try {
            LoginRequest loginRequest = new LoginRequest();
            loginRequest.setEmail(email);
            loginRequest.setUserType(LoginRequest.UserTypeEnum.USER);
            
            LoginResponse response = authApi.login(loginRequest);
            // Fixed: Using proper method names based on typical Swagger codegen patterns
            return new User(
                response.getId() != null ? response.getId().intValue() : 0, 
                response.getName(), 
                email, 
                response.getRole()
            );
        } catch (ApiException e) {
            System.err.println("Erreur de connexion utilisateur: " + e.getMessage());
            return null;
        }
    }
    
    public Admin loginAdmin(String email) {
        try {
            LoginRequest loginRequest = new LoginRequest();
            loginRequest.setEmail(email);
            loginRequest.setUserType(LoginRequest.UserTypeEnum.ADMIN);
            
            LoginResponse response = authApi.login(loginRequest);
            // Fixed: Using proper method names
            return new Admin(
                response.getId() != null ? response.getId().intValue() : 0, 
                response.getName(), 
                email
            );
        } catch (ApiException e) {
            System.err.println("Erreur de connexion admin: " + e.getMessage());
            return null;
        }
    }
    
    // ================= MÉTHODES DE GESTION DES TICKETS =================

    public boolean createTicket(String title, String description, String priority, int creatorID) {
        try {
            CreateTicketRequest ticketRequest = new CreateTicketRequest();
            ticketRequest.setTitle(title);
            ticketRequest.setDescription(description);
            // Fixed: Convert int to Integer properly
            ticketRequest.setCreatorId(Integer.valueOf(creatorID));
            
            switch (priority.toLowerCase()) {
                case "haute":
                    ticketRequest.setPriority(CreateTicketRequest.PriorityEnum.HAUTE);
                    break;
                case "moyenne":
                    ticketRequest.setPriority(CreateTicketRequest.PriorityEnum.MOYENNE);
                    break;
                case "basse":
                    ticketRequest.setPriority(CreateTicketRequest.PriorityEnum.BASSE);
                    break;
                default:
                    ticketRequest.setPriority(CreateTicketRequest.PriorityEnum.MOYENNE);
            }
            
            ticketsApi.createTicket(ticketRequest);
            return true;
        } catch (ApiException e) {
            System.err.println("Erreur création ticket: " + e.getMessage());
            return false;
        }
    }

    public boolean assignTicket(int ticketID, int adminID) {
        try {
            AssignTicketRequest assignRequest = new AssignTicketRequest();
            // Fixed: Convert int to Integer properly
            assignRequest.setAdminId(Integer.valueOf(adminID));
            
            // Fixed: Convert int to Integer properly
            ticketsApi.assignTicket(Integer.valueOf(ticketID), assignRequest);
            return true;
        } catch (ApiException e) {
            System.err.println("Erreur assignation ticket: " + e.getMessage());
            return false;
        }
    }

    public boolean updateTicketStatus(int ticketID, String newStatus) {
        try {
            UpdateStatusRequest statusRequest = new UpdateStatusRequest();
            
            switch (newStatus.toUpperCase()) {
                case "OUVERT":
                    statusRequest.setStatus(UpdateStatusRequest.StatusEnum.OUVERT);
                    break;
                case "ASSIGNE":
                    statusRequest.setStatus(UpdateStatusRequest.StatusEnum.ASSIGNE);
                    break;
                case "VALIDATION":
                    statusRequest.setStatus(UpdateStatusRequest.StatusEnum.VALIDATION);
                    break;
                case "TERMINE":
                    statusRequest.setStatus(UpdateStatusRequest.StatusEnum.TERMINE);
                    break;
                default:
                    return false;
            }
            
            // Fixed: Convert int to Integer properly
            ticketsApi.updateTicketStatus(Integer.valueOf(ticketID), statusRequest);
            return true;
        } catch (ApiException e) {
            System.err.println("Erreur mise à jour statut: " + e.getMessage());
            return false;
        }
    }

    public boolean closeTicket(int ticketID) {
        try {
            // Fixed: Convert int to Integer properly
            ticketsApi.closeTicket(Integer.valueOf(ticketID));
            return true;
        } catch (ApiException e) {
            System.err.println("Erreur fermeture ticket: " + e.getMessage());
            return false;
        }
    }

    public boolean addCommentToTicket(int ticketID, String comment, int userID) {
        try {
            AddCommentRequest commentRequest = new AddCommentRequest();
            commentRequest.setComment(comment);
            // Fixed: Convert int to Integer properly
            commentRequest.setUserId(Integer.valueOf(userID));
            
            // Fixed: Convert int to Integer properly
            ticketsApi.addComment(Integer.valueOf(ticketID), commentRequest);
            return true;
        } catch (ApiException e) {
            System.err.println("Erreur ajout commentaire: " + e.getMessage());
            return false;
        }
    }

    // ================= MÉTHODES DE RECHERCHE =================

    public Optional<Ticket> findTicket(int ticketID) {
        try {
            // Fixed: Convert int to Integer properly
            TicketResponse apiTicket = ticketsApi.getTicketById(Integer.valueOf(ticketID));
            Ticket ticket = convertToLocalTicket(apiTicket);
            return Optional.of(ticket);
        } catch (ApiException e) {
            return Optional.empty();
        }
    }

    public Optional<User> getUserByID(int userID) {
        try {
            List<UserResponse> users = usersApi.getAllUsers();
            for (UserResponse userResp : users) {
                if (userResp.getUserId() != null && userResp.getUserId().intValue() == userID) {
                    return Optional.of(new User(
                        userResp.getUserId().intValue(),
                        userResp.getName(),
                        userResp.getEmail(),
                        userResp.getRole()
                    ));
                }
            }
            return Optional.empty();
        } catch (ApiException e) {
            return Optional.empty();
        }
    }

    public Optional<Admin> getAdminByID(int adminID) {
        try {
            List<AdminResponse> admins = adminsApi.getAllAdmins();
            for (AdminResponse adminResp : admins) {
                if (adminResp.getAdminId() != null && adminResp.getAdminId().intValue() == adminID) {
                    return Optional.of(new Admin(
                        adminResp.getAdminId().intValue(),
                        adminResp.getName(),
                        adminResp.getEmail()
                    ));
                }
            }
            return Optional.empty();
        } catch (ApiException e) {
            return Optional.empty();
        }
    }

    // ================= MÉTHODES DE RAPPORT =================

    public List<Ticket> getUserTickets(int userID) {
        try {
            // Fixed: Convert int to Integer properly
            List<TicketResponse> apiTickets = ticketsApi.getUserTickets(Integer.valueOf(userID));
            List<Ticket> tickets = new ArrayList<>();
            
            for (TicketResponse apiTicket : apiTickets) {
                tickets.add(convertToLocalTicket(apiTicket));
            }
            return tickets;
        } catch (ApiException e) {
            System.err.println("Erreur récupération tickets utilisateur: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public List<Ticket> getAdminAssignedTickets(int adminID) {
        try {
            // Fixed: Convert int to Integer properly
            List<TicketResponse> apiTickets = adminsApi.getAdminAssignedTickets(Integer.valueOf(adminID));
            List<Ticket> tickets = new ArrayList<>();
            
            for (TicketResponse apiTicket : apiTickets) {
                tickets.add(convertToLocalTicket(apiTicket));
            }
            return tickets;
        } catch (ApiException e) {
            System.err.println("Erreur récupération tickets admin: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public List<Ticket> getAllTickets() {
        try {
            List<TicketResponse> apiTickets = ticketsApi.getAllTickets();
            List<Ticket> tickets = new ArrayList<>();
            
            for (TicketResponse apiTicket : apiTickets) {
                tickets.add(convertToLocalTicket(apiTicket));
            }
            return tickets;
        } catch (ApiException e) {
            System.err.println("Erreur récupération tous les tickets: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    // Méthode utilitaire pour convertir TicketResponse → Ticket
    private Ticket convertToLocalTicket(TicketResponse apiTicket) {
        Ticket ticket = new Ticket(
            apiTicket.getTicketId() != null ? apiTicket.getTicketId().intValue() : 0,
            apiTicket.getTitle(),
            apiTicket.getDescription(),
            apiTicket.getStatus() != null ? apiTicket.getStatus().toString() : "OUVERT",
            apiTicket.getPriority() != null ? apiTicket.getPriority().toString() : "moyenne",
            apiTicket.getCreatorId() != null ? apiTicket.getCreatorId().intValue() : 0
        );
        
        if (apiTicket.getAssignedAdminId() != null) {
            ticket.setAssignedAdminID(apiTicket.getAssignedAdminId().intValue());
        }
        
        return ticket;
    }
    
    public int getTicketCounter() {
        return 0;
    }
}