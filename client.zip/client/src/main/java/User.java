import java.util.*;

public class User {
    private int userID;
    private String name;
    private String email;
    private String role;
    
    public User(int userID, String name, String email, String role) {
        this.userID = userID;
        this.email = email;
        this.name = name;
        this.role = role;
    }

    // Getters
    public int getUserID() { return userID; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getRole() { return role; }

    // Méthodes simplifiées
    public void createTicket(Ticket ticket) {
        // Cette logique est maintenant dans TicketController
    }
    
    public void viewTicket(Ticket ticket) {
        // Cette logique est maintenant dans TicketInterface
    }
     
    public static void updateTicket(Ticket ticket) {
        // Cette logique est maintenant dans TicketController
    }
}